<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ratnadeep Dasgupta</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <form class="card col-md-6 mx-auto p-5" method="post">

        <div class="form-group">
            <label for="items">No. of items</label>
            <input type="number" class="form-control" placeholder="Enter no of breads" name="bread" required />
            <input type="number" class="form-control" placeholder="Enter no of vada" name="vada" required />
            <input type="number" class="form-control" placeholder="Enter no of samosa" name="samosa" required />
        </div>

         <div class="form-group">
            <label for="price">Price</label>
            <input type="text" class="form-control" placeholder="Enter the price of vadapav" name="price" required />
            <input type="text" class="form-control" placeholder="Enter the price of samosapav" name="price1" required />
        </div>
       
        <button class="btn btn-block btn-primary" type="submit">Submit</button>
    </form>

    <div class="col-md-6 mx-auto mt-5">
        <div class="card">
            <div class="card-header">Results</div>
            <div class="card-body">
           <?php 
             if (isset($_POST['bread']) && isset($_POST['vada']) && isset($_POST['samosa']) && isset($_POST['price'])&& isset($_POST['price1']) ) {
                     session_start(); 

             $_SESSION['bread'] = $_POST['bread']; 
  
            $_SESSION['vada'] = $_POST['vada']; 
  
            $_SESSION['samosa'] = $_POST['samosa']; 

            $_SESSION['price'] = $_POST['price']; 
  
            $_SESSION['price1'] = $_POST['price1']; 

            $bread = $_SESSION['bread'];
            $vada =  $_SESSION['vada'];
            $samosa = $_SESSION['samosa'];
            $price = $_SESSION['price'];
            $price1= $_SESSION['price1'];
            $maxprice=0;
            
           while($bread>1)
        {  
            if($vada>$samosa)
            {     
                if($bread-2>=2)
                {
                $maxprice+=$vada*$price;
                
                $bread=$bread-(2*$vada);
                $vada=0;
                }
                else
                {
                    $maxprice+=1*$price;
                    $bread=$bread-2;
                }
            }
            else
            {    if($bread-2>=2)
               {
                $maxprice+=$samosa*$price1;
               
                $bread=$bread-($samosa*2);
                $samosa=0;
               }
            else
            {
                $maxprice+=1*$price1;
                $bread=$bread-2;
            }
            
            
        }
        
    }

    echo $maxprice;
                    
                }
              
        
           
?> 
            </div>
        </div>
    </div>
</body>

</html>